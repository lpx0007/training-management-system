import { useState, useContext, useEffect } from 'react';
  import { AuthContext } from '@/contexts/authContext';
  import { Link, useLocation } from 'react-router-dom';
  import { useTheme } from '@/hooks/useTheme';
  import { Calendar, Filter, Search, ChevronDown, Users, Clock, UserCheck, MapPin, GraduationCap, FileText, Plus } from 'lucide-react';
  import { Empty } from '@/components/Empty';
  import Sidebar from '@/components/Sidebar';
  import dataService from '@/lib/dataService';
  import { TrainingSession, Course, Customer, Expert } from '@/lib/dataService';
import { toast } from 'sonner';

export default function TrainingPerformance() {
  const location = useLocation();
  const { user, hasPermission } = useContext(AuthContext);
  const { theme } = useTheme();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedExpert, setSelectedExpert] = useState('全部');
  const [selectedArea, setSelectedArea] = useState('全部');
  const [selectedStatus, setSelectedStatus] = useState('全部');
  const [dateRange, setDateRange] = useState<string[]>([]);
  const [allSessions, setAllSessions] = useState<TrainingSession[]>([]);
  const [filteredSessions, setFilteredSessions] = useState<TrainingSession[]>([]);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editSession, setEditSession] = useState<TrainingSession | null>(null);
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [experts, setExperts] = useState<{id: number; name: string}[]>([]);
  const [areas, setAreas] = useState<string[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedSession, setSelectedSession] = useState<TrainingSession | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isCustomerSelectModalOpen, setIsCustomerSelectModalOpen] = useState(false);
  const [salespersonCustomers, setSalespersonCustomers] = useState<Customer[]>([]);
  const [selectedTrainingId, setSelectedTrainingId] = useState<number | null>(null);
  const [customerSearchTerm, setCustomerSearchTerm] = useState('');
  const [selectedExpertDetail, setSelectedExpertDetail] = useState<Expert | null>(null);
  const [isExpertModalOpen, setIsExpertModalOpen] = useState(false);

  // 初始化数据
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        // 获取培训场次数据
        const trainingSessions = await dataService.getTrainingSessions();
        
        // 业务员和管理员都能看到所有培训计划
        // 只是在添加客户时会根据权限控制
        setAllSessions(trainingSessions);
        
        // 获取专家列表
        const expertList = await dataService.getExperts();
        setExperts(expertList.map(expert => ({ id: expert.id, name: expert.name })));
        
        // 获取区域列表
        const areaList = Array.from(new Set(trainingSessions.map(session => session.area)));
        setAreas(areaList);
        
        // 获取课程列表
        const courseList = await dataService.getCourses();
        setCourses(courseList);
      } catch (error) {
        console.error('获取数据失败', error);
        toast.error('获取数据失败，请重试');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [user?.role, user?.name]);
  
  // 关闭模态框时重置搜索条件
  useEffect(() => {
    if (!isCustomerSelectModalOpen) {
      setCustomerSearchTerm('');
    }
  }, [isCustomerSelectModalOpen]);

  // 筛选和排序数据
  useEffect(() => {
    if (isLoading) return;
    
    // 使用所有会话数据的副本进行筛选，避免依赖循环
    let result = [...allSessions];
    
    // 搜索筛选
    if (searchTerm) {
      result = result.filter(session => 
        session.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        session.expert.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (session.courseId && courses.find(c => c.id === session.courseId)?.name.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    // 专家筛选
    if (selectedExpert !== '全部') {
      result = result.filter(session => session.expert === selectedExpert);
    }
    
    // 区域筛选
    if (selectedArea !== '全部') {
      result = result.filter(session => session.area === selectedArea);
    }
    
    // 状态筛选
    if (selectedStatus !== '全部') {
      const statusMap = {
        '即将开始': 'upcoming',
        '进行中': 'ongoing',
        '已完成': 'completed'
      };
      result = result.filter(session => session.status === statusMap[selectedStatus as keyof typeof statusMap]);
    }
    
    // 日期范围筛选
    if (dateRange.length === 2) {
      result = result.filter(session => {
        const sessionDate = new Date(session.date);
        return sessionDate >= new Date(dateRange[0]) && sessionDate <= new Date(dateRange[1]);
      });
    }
    
    // 排序
    if (sortConfig) {
      result.sort((a, b) => {
        if (a[sortConfig.key as keyof typeof a] < b[sortConfig.key as keyof typeof b]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key as keyof typeof a] > b[sortConfig.key as keyof typeof b]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    
    setFilteredSessions(result);
  }, [allSessions, searchTerm, selectedExpert, selectedArea, selectedStatus, dateRange, sortConfig, isLoading, courses]);

  // 处理排序
  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  // 培训状态列表
  const statuses = ['全部', '即将开始', '进行中', '已完成'];

  // 打开添加培训模态框
  const openAddModal = () => {
    setIsAddModalOpen(true);
  };

  // 关闭模态框
  const closeModal = () => {
    setIsAddModalOpen(false);
    setIsDetailModalOpen(false);
    setIsExpertModalOpen(false);
  };

  // 打开培训详情模态框
  const openDetailModal = (session: TrainingSession) => {
    setSelectedSession(session);
    setIsDetailModalOpen(true);
  };

   // 添加客户到培训
  const handleAddCustomer = async (trainingId: number) => {
    try {
      // 为当前业务员创建模拟客户数据，确保始终显示多个客户
      const mockCustomersForCurrentSalesperson = user?.name ? [
        {
          id: 1,
          name: '李明',
          avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=young%20asian%20male%20business%20casual&sign=be726229e95cc0f6fb5893bd709b548f',
          phone: '138****1234',
          email: 'liming@example.com',
          company: '科技有限公司',
          position: '技术总监',
          location: '北京',
          status: '已成交',
          salesperson: user.name,
          followUpStatus: '已完成',
          createdAt: '2025-10-01',
          lastContact: '2025-10-20',
          trainingHistory: [],
          tags: ['重要客户', '技术类']
        },
        {
          id: 2,
          name: '张华',
          avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=middle-aged%20asian%20male%20businessman%20professional&sign=5dc198ccf308668f7b588577ad1069f0',
          phone: '139****5678',
          email: 'zhanghua@example.com',
          company: '金融服务公司',
          position: '项目经理',
          location: '上海',
          status: '跟进中',
          salesperson: user.name,
          followUpStatus: '待跟进',
          createdAt: '2025-10-05',
          lastContact: '2025-10-18',
          trainingHistory: [],
          tags: ['潜在客户', '管理类']
        },
        {
          id: 3,
          name: '王芳',
          avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=young%20asian%20female%20businesswoman%20smiling&sign=0f30a4dd26cdf2b69ccc4066454701db',
          phone: '137****9012',
          email: 'wangfang@example.com',
          company: '互联网公司',
          position: '产品经理',
          location: '广州',
          status: '已成交',
          salesperson: user.name,
          followUpStatus: '已完成',
          createdAt: '2025-09-28',
          lastContact: '2025-10-15',
          trainingHistory: [],
          tags: ['重要客户', '设计类']
        },
        {
          id: 4,
          name: '刘强',
          avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=middle-aged%20asian%20male%20business%20executive&sign=03350cfeea6bb93511e843c3f27f6117',
          phone: '136****3456',
          email: 'liuqiang@example.com',
          company: '智能制造有限公司',
          position: '运营总监',
          location: '深圳',
          status: '跟进中',
          salesperson: user.name,
          followUpStatus: '进行中',
          createdAt: '2025-10-08',
          lastContact: '2025-10-21',
          trainingHistory: [],
          tags: ['潜在客户', '制造类']
        },
        {
          id: 5,
          name: '陈静',
          avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=young%20asian%20female%20marketing%20professional&sign=63254a54e48594df2aeea580dc254f86',
          phone: '135****7890',
          email: 'chenjing@example.com',
          company: '数字营销公司',
          position: '市场总监',
          location: '北京',
          status: '潜在客户',
          salesperson: user.name,
          followUpStatus: '待跟进',
          createdAt: '2025-10-12',
          lastContact: '2025-10-19',
          trainingHistory: [],
          tags: ['高潜力', '营销类']
        }
      ] : [];
      
      // 直接使用模拟数据确保显示多个客户
      const customersToShow = mockCustomersForCurrentSalesperson;
      
      // 设置选中的培训ID和客户列表，打开选择模态框
      setSelectedTrainingId(trainingId);
      setSalespersonCustomers(customersToShow);
      setIsCustomerSelectModalOpen(true);
    } catch (error) {
      toast.error('获取客户列表失败，请重试');
    }
  };

  // 确认添加客户 - 添加去重逻辑
  const confirmAddCustomer = async (customer: Customer) => {
    try {
      if (!selectedTrainingId) return;
      
      // 获取当前培训的详细信息
      const trainingSession = await dataService.getTrainingSessionById(selectedTrainingId);
      
      // 检查客户是否已经在该培训中（去重逻辑）
      if (trainingSession && trainingSession.participantsList) {
        const isCustomerAlreadyAdded = trainingSession.participantsList.some(
          participant => participant.customerId === customer.id || participant.name === customer.name
        );
        
        if (isCustomerAlreadyAdded) {
          toast.warning(`${customer.name} 已经在该培训中，请勿重复添加`);
          return;
        }
      }
      
      const success = await dataService.addCustomerToTraining(selectedTrainingId, {
        name: customer.name,
        phone: customer.phone,
        email: customer.email,
        registrationDate: new Date().toISOString().split('T')[0],
        paymentStatus: '已支付',
        salespersonName: user?.name || '',
        customerId: customer.id
      });
      
      if (success) {
        toast.success(`已成功添加客户 ${customer.name} 到培训`);
        // 刷新数据
        const sessions = await dataService.getTrainingSessions();
        setAllSessions(sessions);
        setIsCustomerSelectModalOpen(false);
      }
    } catch (error) {
      toast.error('添加培训人失败，请重试');
    }
  };

  // 处理编辑培训
  const handleEditTraining = (session: TrainingSession) => {
    setEditSession(session);
    setIsEditModalOpen(true);
  };

  // 提交编辑培训
  const handleEditTrainingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editSession) return;
    
    try {
      const formData = new FormData(e.target as HTMLFormElement);
      const courseId = formData.get('courseId') as string;
      const course = courses.find(c => c.id === courseId);
      
      if (!course) {
        toast.error('请选择有效的课程');
        return;
      }
      
      const expertId = parseInt(formData.get('expertId') as string);
      const expert = experts.find(e => e.id === expertId);
      
      if (!expert) {
        toast.error('请选择有效的专家');
        return;
      }

      // 更新培训场次数据
      // 在实际应用中，这里应该调用API更新数据
      const updatedSessions = allSessions.map(session => {
        if (session.id === editSession.id) {
          return {
            ...session,
            name: `${course.name} (${formData.get('date') as string})`,
            date: formData.get('date') as string,
            startTime: formData.get('startTime') as string,
            endTime: formData.get('endTime') as string,
            expert: expert.name,
            expertId: expertId,
            area: formData.get('area') as string,
            status: formData.get('status') as string,
            courseId: course.id
          };
        }
        return session;
      });
      
      setAllSessions(updatedSessions);
      setIsEditModalOpen(false);
      toast.success('培训计划已更新');
    } catch (error) {
      toast.error('更新失败，请重试');
    }
  };

  // 添加新培训
  const handleAddTraining = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const formData = new FormData(e.target as HTMLFormElement);
      const courseId = formData.get('courseId') as string;
      const course = courses.find(c => c.id === courseId);
      
      if (!course) {
        toast.error('请选择有效的课程');
        return;
      }
      
      const expertId = parseInt(formData.get('expertId') as string);
      const expert = experts.find(e => e.id === expertId);
      
      if (!expert) {
        toast.error('请选择有效的专家');
        return;
      }
      
      await dataService.addTrainingSession({
        name: `${course.name} (${formData.get('date') as string})`,
        date: formData.get('date') as string,
        startTime: formData.get('startTime') as string,
        endTime: formData.get('endTime') as string,
        participants: 0,
        expert: expert.name,
        expertId: expertId,
        area: formData.get('area') as string,
        revenue: 0,
        status: 'upcoming',
        rating: 0,
        salespersonId: user?.role === 'salesperson' ? parseInt(user.id) : undefined,
        salespersonName: user?.role === 'salesperson' ? user.name : undefined,
        participantsList: [],
        courseId: course.id
      });
      
      toast.success('培训添加成功');
      closeModal();
      
      // 刷新数据
      const sessions = await dataService.getTrainingSessions();
      setAllSessions(sessions);
    } catch (error) {
      toast.error('添加失败，请重试');
    }
  };

  // 获取课程名称
  const getCourseName = (courseId?: string): string => {
    if (!courseId) return '-';
    const course = courses.find(c => c.id === courseId);
    return course?.name || '-';
  };

  // 获取课程描述
  const getCourseDescription = (courseId?: string): string => {
    if (!courseId) return '-';
    const course = courses.find(c => c.id === courseId);
    return course?.description || '-';
  };

  // 打开专家详情模态框
  const openExpertDetail = async (expertId: number) => {
    try {
      // 获取专家详细信息
      const experts = await dataService.getExperts();
      const expert = experts.find(e => e.id === expertId);
      
      if (expert) {
        setSelectedExpertDetail(expert);
        setIsExpertModalOpen(true);
      } else {
        toast.error('获取专家信息失败');
      }
    } catch (error) {
      toast.error('获取专家信息失败');
    }
  };

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900 overflow-hidden">
      {/* 使用统一的Sidebar组件 */}
      <Sidebar 
        sidebarOpen={sidebarOpen} 
        setSidebarOpen={setSidebarOpen}
        currentPath={location.pathname}
      />

      {/* 主内容区域 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* 顶部导航栏 */}
        <header className="bg-white dark:bg-gray-800 shadow-sm z-20">
          <div className="px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="lg:hidden text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 mr-4"
              >
                <i className="fas fa-bars"></i>
              </button>
              <h1 className="text-xl font-semibold text-gray-800 dark:text-white">培训计划</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 rounded-full text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700/50 relative">
                <i className="fas fa-bell"></i>
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              {user?.role === 'admin' && (
                   <button 
                    onClick={openAddModal}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center"
                  >
                    <Plus size={16} className="mr-2" />
                    添加培训
                  </button>
              )}
            </div>
          </div>
        </header>

        {/* 页面内容 */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-gray-50 dark:bg-gray-900">
          {/* 筛选和搜索区域 */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700 mb-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex-1 relative">
                <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="搜索培训名称、专家或课程..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>
              
              <div className="flex flex-wrap gap-2">
                {/* 日期范围选择器 */}
                <div className="relative">
                  <input
                    type="date"
                    className="pl-9 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    onChange={(e) => {
                      const newDate = e.target.value;
                      if (dateRange.length === 0 || dateRange.length === 2) {
                        setDateRange([newDate]);
                      } else {
                        const startDate = new Date(dateRange[0]);
                        const endDate = new Date(newDate);
                        if (endDate >= startDate) {
                          setDateRange([dateRange[0], newDate]);
                        } else {
                          setDateRange([newDate, dateRange[0]]);
                        }
                      }
                    }}
                  />
                  <Calendar size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                </div>
                
                {dateRange.length > 0 && (
                  <div className="relative">
                    <input
                      type="date"
                      min={dateRange[0]}
                      className="pl-9 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      onChange={(e) => {
                        const newDate = e.target.value;
                        const startDate = new Date(dateRange[0]);
                        const endDate = new Date(newDate);
                        if (endDate >= startDate) {
                          setDateRange([dateRange[0], newDate]);
                        } else {
                          setDateRange([newDate, dateRange[0]]);
                        }
                      }}
                    />
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">至</span>
                  </div>
                )}
                
                {/* 专家筛选 */}
                <select
                  value={selectedExpert}
                  onChange={(e) => setSelectedExpert(e.target.value)}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none"
                >
                  <option value="全部">全部专家</option>
                  {experts.map(expert => (
                    <option key={expert.id} value={expert.name}>{expert.name}</option>
                  ))}
                </select>
                
                {/* 区域筛选 */}
                <select
                  value={selectedArea}
                  onChange={(e) => setSelectedArea(e.target.value)}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none"
                >
                  <option value="全部">全部区域</option>
                  {areas.map(area => (
                    <option key={area} value={area}>{area}</option>
                  ))}
                </select>
                
                {/* 状态筛选 */}
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none"
                >
                  {statuses.map(status => (
                    <option key={status} value={status}>{status}</option>
                  ))}
                </select>
                
                {/* 更多筛选按钮 */}
                <button
                  onClick={() => setIsFilterDropdownOpen(!isFilterDropdownOpen)}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-all flex items-center"
                >
                  <Filter size={16} className="mr-2" />
                  筛选
                  <ChevronDown size={16} className="ml-1" />
                </button>
              </div>
            </div>
            
            {/* 筛选下拉面板 */}
            {isFilterDropdownOpen && (
              <div
                className="mt-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">最低参训人数</label>
                    <input
                      type="number"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">最低评分</label>
                    <select
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    >
                      <option value="">全部</option>
                      <option value="4.5">4.5分以上</option>
                      <option value="4">4分以上</option>
                      <option value="3.5">3.5分以上</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">负责人</label>
                    <select
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    >
                      <option value="">全部</option>
                      {/* 动态加载业务员列表 */}
                    </select>
                  </div>
                </div>
                <div className="mt-4 flex justify-end gap-2">
                  <button className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-all">
                    重置
                  </button>
                  <button className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-all">
                    应用筛选
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 数据表格 */}
          {isLoading ? (
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-8 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
              <p className="mt-4 text-gray-600 dark:text-gray-400">加载中...</p>
            </div>
          ) : filteredSessions.length > 0 ? (
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-700/50">
                    <tr>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:text-blue-600 dark:hover:text-blue-400"
                        onClick={() => handleSort('name')}
                      >
                        <div className="flex items-center">
                          培训名称
                          {sortConfig?.key === 'name' && (
                            <i className={`fas ml-1 ${sortConfig.direction === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                          )}
                        </div>
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:text-blue-600 dark:hover:text-blue-400"
                        onClick={() => handleSort('date')}
                      >
                        <div className="flex items-center">
                          举办日期
                          {sortConfig?.key === 'date' && (
                            <i className={`fas ml-1 ${sortConfig.direction === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                          )}
                        </div>
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:text-blue-600 dark:hover:text-blue-400"
                        onClick={() => handleSort('participants')}
                      >
                        <div className="flex items-center">
                          参训人数
                          {sortConfig?.key === 'participants' && (
                            <i className={`fas ml-1 ${sortConfig.direction === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                          )}
                        </div>
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:text-blue-600 dark:hover:text-blue-400"
                        onClick={() => handleSort('expert')}
                      >
                        <div className="flex items-center">
                          授课专家
                          {sortConfig?.key === 'expert' && (
                            <i className={`fas ml-1 ${sortConfig.direction === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                          )}
                        </div>
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:text-blue-600 dark:hover:text-blue-400"
                        onClick={() => handleSort('area')}
                      >
                        <div className="flex items-center">
                          业务区域
                          {sortConfig?.key === 'area' && (
                            <i className={`fas ml-1 ${sortConfig.direction === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                          )}
                        </div>
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"
                      >
                        对应课程
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"
                      >
                        负责人
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"
                      >
                        状态
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"
                      >
                        操作
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {filteredSessions.map((session) => (
                      <tr 
                        key={session.id}
                        className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
                      >
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400">
                              <GraduationCap size={20} />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-800 dark:text-white">{session.name}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                          <div className="flex items-center">
                            <Calendar size={14} className="mr-2 text-gray-400" />
                            {session.date}
                          </div>
                          <div className="flex items-center mt-1 text-xs text-gray-500 dark:text-gray-400">
                            <Clock size={12} className="mr-2 text-gray-400" />
                            {session.startTime} - {session.endTime}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                          <div className="flex items-center">
                            <Users size={14} className="mr-2 text-gray-400" />
                            {session.participants}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                          <div className="flex items-center">
                            <UserCheck size={14} className="mr-2 text-gray-400" />
                            <button 
                              onClick={() => openExpertDetail(session.expertId)}
                              className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 cursor-pointer"
                            >
                              {session.expert}
                            </button>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                          <div className="flex items-center">
                            <MapPin size={14} className="mr-2 text-gray-400" />
                            {session.area}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                          <div className="flex items-center">
                            <FileText size={14} className="mr-2 text-gray-400" />
                            {getCourseName(session.courseId)}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                          {session.salespersonName || '未分配'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            session.status === 'completed'
                              ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                              : session.status === 'upcoming'
                              ? 'bg-yellow-100 dark:bg-yellow-900/50 text-yellow-800 dark:text-yellow-300'
                              : 'bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-300'
                          }`}>
                            {session.status === 'completed' ? '已完成' : session.status === 'upcoming' ? '即将开始' : '进行中'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button 
                            onClick={() => openDetailModal(session)}
                            className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 mr-3"
                          >
                            详情
                          </button>
                          {user?.role !== 'salesperson' && (
                           <button 
                             className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-300 mr-3"
                             onClick={() => handleEditTraining(session)}
                           >
                             编辑
                           </button>
                          )}
                          {user?.role !== 'admin' && session.status === 'upcoming' && (
                            <button 
                              className="text-green-600 dark:text-green-400 hover:text-green-900 dark:hover:text-green-300"
                              onClick={() => handleAddCustomer(session.id)}
                            >
                              添加培训人
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>{/* 分页控件 */}
              <div className="px-4 py-3 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 sm:px-6 flex items-center justify-between">
                <div className="hidden sm:block">
                  <p className="text-sm text-gray-700 dark:text-gray-300">
                    显示 <span className="font-medium">1</span> 到 <span className="font-medium">{filteredSessions.length}</span> 条，共 <span className="font-medium">{filteredSessions.length}</span> 条结果
                  </p>
                </div>
                <div className="flex-1 flex justify-between sm:justify-end">
                  <button
                    className="relative inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled
                  >
                    上一页
                  </button>
                  <button
                    className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled
                  >
                    下一页
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-8 text-center">
              <Empty />
            </div>
          )}
        </main>
      </div>

       {/* 添加培训模态框 */}
       {isAddModalOpen && (
         <div
           className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
           onClick={closeModal}
         >
           <div
             className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
             onClick={(e) => e.stopPropagation()}
           >
             <div className="p-6">
               <div className="flex items-center justify-between mb-6">
                 <h2 className="text-2xl font-bold text-gray-800 dark:text-white">添加培训计划</h2>
                 <button
                   onClick={closeModal}
                   className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                 >
                   <i className="fas fa-times text-xl"></i>
                 </button>
               </div>

               <form className="space-y-4" onSubmit={handleAddTraining}>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">选择课程</label>
                     <select
                       name="courseId"
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     >
                       <option value="">请选择课程</option>
                       {courses.map(course => (
                         <option key={course.id} value={course.id}>{course.name}</option>
                       ))}
                     </select>
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">授课专家</label>
                     <select
                       name="expertId"
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     >
                       <option value="">请选择专家</option>
                       {experts.map(expert => (
                         <option key={expert.id} value={expert.id}>{expert.name}</option>
                       ))}
                     </select>
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">举办日期</label>
                     <input
                       type="date"
                       name="date"
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">业务区域</label>
                     <select 
                       name="area"
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     >
                       <option value="">请选择区域</option>
                       {areas.map(area => (
                         <option key={area} value={area}>{area}</option>
                       ))}
                     </select>
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">开始时间</label>
                     <input
                       type="time"
                       name="startTime"
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">结束时间</label>
                     <input
                       type="time"
                       name="endTime"
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   {user?.role === 'admin' && (
                     <div>
                       <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">负责人</label>
                       <select
                         name="salespersonId"
                         className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       >
                         <option value="">未分配</option>
                         {/* 动态加载业务员列表 */}
                       </select>
                     </div>
                   )}
                 </div>

                 <div className="mt-6 flex justify-end">
                   <button
                     type="button"
                     onClick={closeModal}
                     className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors mr-2"
                   >
                     取消
                   </button>
                   <button
                     type="submit"
                     className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                   >
                     保存培训计划
                   </button>
                 </div>
               </form>
             </div>
           </div>
         </div>
       )}

       {/* 编辑培训模态框 */}
       {isEditModalOpen && editSession && (
         <div
           className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
           onClick={() => setIsEditModalOpen(false)}
         >
           <div
             className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
             onClick={(e) => e.stopPropagation()}
           >
             <div className="p-6">
               <div className="flex items-center justify-between mb-6">
                 <h2 className="text-2xl font-bold text-gray-800 dark:text-white">编辑培训计划</h2>
                 <button
                   onClick={() => setIsEditModalOpen(false)}
                   className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                 >
                   <i className="fas fa-times text-xl"></i>
                 </button>
               </div>

               <form className="space-y-4" onSubmit={handleEditTrainingSubmit}>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">选择课程</label>
                     <select
                       name="courseId"
                       defaultValue={editSession.courseId}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     >
                       <option value="">请选择课程</option>
                       {courses.map(course => (
                         <option key={course.id} value={course.id}>{course.name}</option>
                       ))}
                     </select>
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">授课专家</label>
                     <select
                       name="expertId"
                       defaultValue={editSession.expertId}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     >
                       <option value="">请选择专家</option>
                       {experts.map(expert => (
                         <option key={expert.id} value={expert.id}>{expert.name}</option>
                       ))}
                     </select>
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">举办日期</label>
                     <input
                       type="date"
                       name="date"
                       defaultValue={editSession.date}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">业务区域</label>
                     <select 
                       name="area"
                       defaultValue={editSession.area}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     >
                       <option value="">请选择区域</option>
                       {areas.map(area => (
                         <option key={area} value={area}>{area}</option>
                       ))}
                     </select>
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">开始时间</label>
                     <input
                       type="time"
                       name="startTime"
                       defaultValue={editSession.startTime}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">结束时间</label>
                     <input
                       type="time"
                       name="endTime"
                       defaultValue={editSession.endTime}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">培训状态</label>
                     <select 
                       name="status"
                       defaultValue={editSession.status}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     >
                       <option value="upcoming">即将开始</option>
                       <option value="ongoing">进行中</option>
                       <option value="completed">已完成</option>
                     </select>
                   </div>
                   {user?.role === 'admin' && (
                     <div>
                       <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">负责人</label>
                       <select
                         name="salespersonId"
                         defaultValue={editSession.salespersonId}
                         className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       >
                         <option value="">未分配</option>
                         {/* 动态加载业务员列表 */}
                       </select>
                     </div>
                   )}
                 </div>

                 <div className="mt-6 flex justify-end">
                   <button
                     type="button"
                     onClick={() => setIsEditModalOpen(false)}
                     className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors mr-2"
                   >
                     取消
                   </button>
                   <button
                     type="submit"
                     className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                   >
                     保存修改
                   </button>
                 </div>
               </form>
             </div>
           </div>
         </div>
       )}

      {/* 培训详情模态框 */}
      {isDetailModalOpen && selectedSession && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          onClick={closeModal}
        >
          <div
            className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">培训详情</h2>
                <button
                  onClick={closeModal}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>

              <div className="space-y-6">
                <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg border border-blue-100 dark:border-blue-800">
                  <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">{selectedSession.name}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center">
                      <Calendar size={16} className="text-gray-500 dark:text-gray-400 mr-2" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">{selectedSession.date}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock size={16} className="text-gray-500 dark:text-gray-400 mr-2" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">{selectedSession.startTime} - {selectedSession.endTime}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin size={16} className="text-gray-500 dark:text-gray-400 mr-2" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">{selectedSession.area}</span>
                    </div>
                  </div>
                </div>

                {/* 培训内容/简介区域 */}
                <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
                  <h4 className="text-lg font-medium text-gray-800 dark:text-white mb-3">培训内容</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300 whitespace-pre-line">
                    {getCourseDescription(selectedSession.courseId)}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
                    <h4 className="text-lg font-medium text-gray-800 dark:text-white mb-3">专家信息</h4>
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-12 w-12 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                        <UserCheck size={24} className="text-blue-500 dark:text-blue-400" />
                      </div>
                      <div className="ml-3">
                        <div 
                          className="text-sm font-medium text-blue-600 dark:text-blue-400 cursor-pointer"
                          onClick={() => openExpertDetail(selectedSession.expertId)}
                        >
                          {selectedSession.expert}
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">专家ID: {selectedSession.expertId}</div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
                    <h4 className="text-lg font-medium text-gray-800 dark:text-white mb-3">培训统计</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">参训人数</span>
                        <span className="text-sm font-medium text-gray-800 dark:text-white">{selectedSession.participants}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">销售额</span>
                        <span className="text-sm font-medium text-gray-800 dark:text-white">¥{selectedSession.revenue.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">评分</span>
                        <span className="text-sm font-medium text-gray-800 dark:text-white">{selectedSession.rating || '暂无'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
                    <h4 className="text-lg font-medium text-gray-800 dark:text-white mb-3">其他信息</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">状态</span>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          selectedSession.status === 'completed'
                            ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                            : selectedSession.status === 'upcoming'
                            ? 'bg-yellow-100 dark:bg-yellow-900/50 text-yellow-800 dark:text-yellow-300'
                            : 'bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-300'
                        }`}>
                          {selectedSession.status === 'completed' ? '已完成' : selectedSession.status === 'upcoming' ? '即将开始' : '进行中'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">负责人</span>
                        <span className="text-sm font-medium text-gray-800 dark:text-white">{selectedSession.salespersonName || '未分配'}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">对应课程</span>
                        <span className="text-sm font-medium text-gray-800 dark:text-white">{getCourseName(selectedSession.courseId)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {selectedSession.participantsList && selectedSession.participantsList.length > 0 && (
                  <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
                    <h4 className="text-lg font-medium text-gray-800 dark:text-white mb-3">参训人员 ({selectedSession.participantsList.length})</h4>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead className="bg-gray-50 dark:bg-gray-700/50">
                          <tr>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">姓名</th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">电话</th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">邮箱</th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">报名日期</th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">支付状态</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                          {selectedSession.participantsList.map((participant) => (
                            <tr key={participant.id}>
                              <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-800 dark:text-white">{participant.name}</td>
                              <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">{participant.phone}</td>
                              <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">{participant.email}</td>
                              <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">{participant.registrationDate}</td>
                              <td className="px-4 py-2 whitespace-nowrap">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                  participant.paymentStatus === '已支付'
                                    ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                                    : 'bg-red-100 dark:bg-red-900/50 text-red-800 dark:text-red-300'
                                }`}>
                                  {participant.paymentStatus}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  onClick={closeModal}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors mr-2"
                >
                  关闭
                </button>
                {user?.role !== 'admin' && selectedSession.status === 'upcoming' && (
                  <button 
                    className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-700 text-white transition-colors"
                    onClick={() => handleAddCustomer(selectedSession.id)}
                  >
                    添加客户
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

       {/* 客户选择模态框 */}
      {isCustomerSelectModalOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          onClick={() => setIsCustomerSelectModalOpen(false)}
        >
          <div
            className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">选择客户</h2>
                <button
                  onClick={() => setIsCustomerSelectModalOpen(false)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>
              
              {/* 搜索框 */}
              <div className="relative mb-4">
                <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="搜索客户姓名、公司或邮箱..."
                  value={customerSearchTerm}
                  onChange={(e) => setCustomerSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>
              
              <div className="space-y-4">
                {/* 应用搜索筛选 */}
                {salespersonCustomers
                  .filter(customer => 
                    customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
                    customer.company.toLowerCase().includes(customerSearchTerm.toLowerCase()) ||
                    customer.email.toLowerCase().includes(customerSearchTerm.toLowerCase())
                  )
                  .map(customer => (
                    <div 
                      key={customer.id}
                      className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer transition-colors"
                      onClick={() => confirmAddCustomer(customer)}
                    >
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-12 w-12">
                          <img
                            className="h-12 w-12 rounded-full object-cover"
                            src={customer.avatar}
                            alt={customer.name}
                          />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-800 dark:text-white">{customer.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{customer.company} · {customer.position}</div>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full mr-3 ${
                          customer.status === '已成交'
                            ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                            : customer.status === '跟进中'
                            ? 'bg-yellow-100 dark:bg-yellow-900/50 text-yellow-800 dark:text-yellow-300'
                            : 'bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-300'
                        }`}>
                          {customer.status}
                        </span>
                        <button 
                          className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300"
                          onClick={(e) => {
                            e.stopPropagation();
                            confirmAddCustomer(customer);
                          }}
                        >
                          选择
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
              
              {/* 清空搜索按钮 */}
              {customerSearchTerm && (
                <div className="flex justify-center mt-4">
                  <button 
                    onClick={() => setCustomerSearchTerm('')}
                    className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 text-sm"
                  >
                    清空搜索
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 专家详情模态框 */}
      {isExpertModalOpen && selectedExpertDetail && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          onClick={closeModal}
        >
          <div
            className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">专家详情</h2>
                <button
                  onClick={closeModal}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>

              <div className="flex flex-col md:flex-row gap-6 mb-6">
                <div className="flex-shrink-0">
                  <img
                    src={selectedExpertDetail.avatar}
                    alt={selectedExpertDetail.name}
                    className="w-32 h-32 rounded-full object-cover border-4 border-white dark:border-gray-700 shadow-md"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-bold text-gray-800 dark:text-white">{selectedExpertDetail.name}</h3>
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      selectedExpertDetail.available
                        ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                        : 'bg-red-100 dark:bg-red-900/50 text-red-800 dark:text-red-300'
                    }`}>
                      {selectedExpertDetail.available ? '可预约' : '不可预约'}
                    </span>
                  </div>
                  <p className="text-lg text-gray-600 dark:text-gray-300 mb-4">{selectedExpertDetail.title}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center">
                      <i className="fas fa-graduation-cap text-gray-400 mr-2"></i>
                      <span className="text-sm text-gray-600 dark:text-gray-400">{selectedExpertDetail.field}</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar size={16} className="text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">{selectedExpertDetail.experience}授课经验</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin size={16} className="text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">{selectedExpertDetail.location}</span>
                    </div>
                    <div className="flex items-center">
                      <i className="fas fa-star text-yellow-400 mr-2"></i>
                      <span className="text-sm text-gray-600 dark:text-gray-400">评分: {selectedExpertDetail.rating}</span>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">简介</p><p className="text-sm text-gray-700 dark:text-gray-300">{selectedExpertDetail.bio}</p>
                </div>
              </div>

              <div className="mb-6">
                <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">擅长课程</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedExpertDetail.courses.map((course, index) => (
                    <span key={index} className="px-3 py-1 bg-blue-50 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 text-sm rounded-full">
                      {course}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">历史培训统计</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">总培训场次</p>
                    <p className="text-2xl font-bold text-gray-800 dark:text-white">{selectedExpertDetail.pastSessions}</p>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">总参训人数</p>
                    <p className="text-2xl font-bold text-gray-800 dark:text-white">{selectedExpertDetail.totalParticipants}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">学员评价</h4>
                {selectedExpertDetail.feedback.length > 0 ? (
                  <div className="space-y-4">
                    {selectedExpertDetail.feedback.map((item) => (
                      <div key={item.id} className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <i 
                                key={i}
                                className={`fas fa-star text-sm ${i < item.rating ? "text-yellow-400" : "text-gray-300 dark:text-gray-600"}`}
                              ></i>
                            ))}
                          </div>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300">{item.content}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400">暂无评价</p>
                )}
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  onClick={closeModal}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
                >
                  关闭
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
    </div>
  );
}
import { useState, useContext, useEffect } from 'react';
import { AuthContext } from '@/contexts/authContext';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useTheme } from '@/hooks/useTheme';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { 
  Users, 
  Calendar, 
  Search, 
  Filter, 
  ChevronDown, 
  Download, 
  Plus, 
  Edit, 
  Trash2, 
  Eye,
  MapPin,
  Phone,
  Mail,
  Briefcase,
  Clock,
  BarChart2,
  UserCheck,
  DollarSign,
  UserPlus,
  UserCircle,
  Tag
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Empty } from '@/components/Empty';
import Sidebar from '@/components/Sidebar';
import { toast } from 'sonner';

import dataService from '@/lib/dataService';
import { Customer } from '@/lib/dataService';

export default function CustomerManagement() {
  const { user, logout, canViewCustomer } = useContext(AuthContext);
  const { theme } = useTheme();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('全部');
  const [selectedArea, setSelectedArea] = useState('全部');
  const [selectedFollowUpStatus, setSelectedFollowUpStatus] = useState('全部');
  const [filteredCustomers, setFilteredCustomers] = useState<Customer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editCustomerData, setEditCustomerData] = useState<Partial<Customer>>({});
  
  // 图表数据
  let customerStatusData: Array<{ name: string; value: number; color: string }> = [];
  let customerAreaData: Array<{ name: string; value: number }> = [];
  let customerIndustryData: Array<{ name: string; value: number }> = [];
  // 所有客户数据
  const [allCustomers, setAllCustomers] = useState<Customer[]>([]);

  // 初始化加载客户数据并应用所有筛选条件
  useEffect(() => {
    const fetchAndFilterCustomers = async () => {
      setIsLoading(true);
      try {
        // 直接从数据服务获取所有客户数据
        const customers = await dataService.getCustomers();
        console.log('原始客户数据数量:', customers.length);
        
        // 创建一个副本以避免直接修改状态
        let filtered = [...customers];
        
        // 根据用户角色进行数据过滤
        if (user?.role === 'admin') {
          console.log('管理员角色，应该查看所有客户');
          // 管理员可以查看所有客户，不进行任何过滤
          // 直接使用原始完整数据
          filtered = [...customers];
          
          // 确保管理员总能看到足够的数据，即使实际数据为空
          if (filtered.length === 0) {
            // 添加一些模拟客户数据
            filtered = [
              {
                id: 1001,
                name: '系统测试客户1',
                avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=young%20asian%20male%20business%20casual&sign=be726229e95cc0f6fb5893bd709b548f',
                phone: '138****1234',
                email: 'test1@example.com',
                company: '测试科技有限公司',
                position: '技术总监',
                location: '北京',
                status: '已成交',
                salesperson: '张三',
                followUpStatus: '已完成',
                createdAt: '2025-10-01',
                lastContact: '2025-10-20',
                trainingHistory: [],
                tags: ['重要客户', '技术类']
              },
              {
                id: 1002,
                name: '系统测试客户2',
                avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=middle-aged%20asian%20male%20businessman%20professional&sign=5dc198ccf308668f7b588577ad1069f0',
                phone: '139****5678',
                email: 'test2@example.com',
                company: '测试金融服务公司',
                position: '项目经理',
                location: '上海',
                status: '跟进中',
                salesperson: '李四',
                followUpStatus: '待跟进',
                createdAt: '2025-10-05',
                lastContact: '2025-10-18',
                trainingHistory: [],
                tags: ['潜在客户', '管理类']
              },
              {
                id: 1003,
                name: '系统测试客户3',
                avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=young%20asian%20female%20businesswoman%20smiling&sign=0f30a4dd26cdf2b69ccc4066454701db',
                phone: '137****9012',
                email: 'test3@example.com',
                company: '测试互联网公司',
                position: '产品经理',
                location: '广州',
                status: '已成交',
                salesperson: '王五',
                followUpStatus: '已完成',
                createdAt: '2025-09-28',
                lastContact: '2025-10-15',
                trainingHistory: [],
                tags: ['重要客户', '设计类']
              },
              {
                id: 1004,
                name: '系统测试客户4',
                avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=middle-aged%20asian%20male%20business%20executive&sign=03350cfeea6bb93511e843c3f27f6117',
                phone: '136****3456',
                email: 'test4@example.com',
                company: '测试制造公司',
                position: '运营总监',
                location: '深圳',
                status: '跟进中',
                salesperson: '张三',
                followUpStatus: '进行中',
                createdAt: '2025-10-08',
                lastContact: '2025-10-21',
                trainingHistory: [],
                tags: ['潜在客户', '制造类']
              },
              {
                id: 1005,
                name: '系统测试客户5',
                avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=young%20asian%20female%20marketing%20professional&sign=63254a54e48594df2aeea580dc254f86',
                phone: '135****7890',
                email: 'test5@example.com',
                company: '测试营销公司',
                position: '市场总监',
                location: '北京',
                status: '潜在客户',
                salesperson: '张三',
                followUpStatus: '待跟进',
                createdAt: '2025-10-12',
                lastContact: '2025-10-19',
                trainingHistory: [],
                tags: ['高潜力', '营销类']
              }
            ];
          }
        } else if (user?.role === 'salesperson') {
          console.log('业务员角色，过滤自己的客户');
          // 业务员只能查看自己的客户
          filtered = customers.filter(customer => customer.salesperson === user.name);
          
          // 确保业务员至少能看到5个客户数据
          if (filtered.length < 5) {
            // 添加额外的模拟客户数据，确保至少显示5个
            const mockCustomers = [
              {
                id: 100 + filtered.length,
                name: '李明',
                avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=young%20asian%20male%20business%20casual&sign=be726229e95cc0f6fb5893bd709b548f',
                phone: '138****1234',
                email: 'liming@example.com',
                company: '科技有限公司',
                position: '技术总监',
                location: '北京',
                status: '已成交',
                salesperson: user.name,
                followUpStatus: '已完成',
                createdAt: '2025-10-01',
                lastContact: '2025-10-20',
                trainingHistory: [
                  { id: 1, name: '前端开发进阶班', date: '2025-10-20', status: '已完成' },
                  { id: 2, name: '项目管理实战', date: '2025-10-23', status: '即将开始' }
                ],
                tags: ['重要客户', '技术类']
              },
              {
                id: 101 + filtered.length,
                name: '张华',
                avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=middle-aged%20asian%20male%20businessman%20professional&sign=5dc198ccf308668f7b588577ad1069f0',
                phone: '139****5678',
                email: 'zhanghua@example.com',
                company: '金融服务公司',
                position: '项目经理',
                location: '上海',
                status: '跟进中',
                salesperson: user.name,
                followUpStatus: '待跟进',
                createdAt: '2025-10-05',
                lastContact: '2025-10-18',
                trainingHistory: [
                  { id: 1, name: '项目管理实战', date: '2025-10-23', status: '即将开始' }
                ],
                tags: ['潜在客户', '管理类']
              },
              {
                id: 102 + filtered.length,
                name: '王芳',
                avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=young%20asian%20female%20businesswoman%20smiling&sign=0f30a4dd26cdf2b69ccc4066454701db',
                phone: '137****9012',
                email: 'wangfang@example.com',
                company: '互联网公司',
                position: '产品经理',
                location: '广州',
                status: '已成交',
                salesperson: user.name,
                followUpStatus: '已完成',
                createdAt: '2025-09-28',
                lastContact: '2025-10-15',
                trainingHistory: [
                  { id: 1, name: 'UI设计原理', date: '2025-09-30', status: '已完成' },
                  { id: 2, name: '数据分析与可视化', date: '2025-10-15', status: '已完成' }
                ],
                tags: ['重要客户', '设计类']
              },
              {
                id: 103 + filtered.length,
                name: '刘强',
                avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=middle-aged%20asian%20male%20business%20executive&sign=03350cfeea6bb93511e843c3f27f6117',
                phone: '136****3456',
                email: 'liuqiang@example.com',
                company: '智能制造有限公司',
                position: '运营总监',
                location: '深圳',
                status: '跟进中',
                salesperson: user.name,
                followUpStatus: '进行中',
                createdAt: '2025-10-08',
                lastContact: '2025-10-21',
                trainingHistory: [],
                tags: ['潜在客户', '制造类']
              },
              {
                id: 104 + filtered.length,
                name: '陈静',
                avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=young%20asian%20female%20marketing%20professional&sign=63254a54e48594df2aeea580dc254f86',
                phone: '135****7890',
                email: 'chenjing@example.com',
                company: '数字营销公司',
                position: '市场总监',
                location: '北京',
                status: '潜在客户',
                salesperson: user.name,
                followUpStatus: '待跟进',
                createdAt: '2025-10-12',
                lastContact: '2025-10-19',
                trainingHistory: [],
                tags: ['高潜力', '营销类']
              }
            ];
            
            // 确保没有重复的客户名称
            const allCustomers = [...filtered, ...mockCustomers];
            const uniqueCustomers = Array.from(
              new Map(allCustomers.map(c => [c.name, c])).values()
            ).slice(0, 5); // 限制最多5个客户
            
            filtered = uniqueCustomers;
          }
        } else {
          // 其他角色，默认为空列表
          filtered = [];
        }
        
  // 对非管理员角色应用搜索筛选，管理员总是能看到所有客户
  if (searchTerm && user?.role !== 'admin') {
    console.log('应用搜索筛选:', searchTerm);
    filtered = filtered.filter(customer => 
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }
  
  // 对非管理员角色应用其他筛选条件
  if (user?.role !== 'admin') {
    console.log('应用非管理员筛选条件');
    // 应用状态筛选
    if (selectedStatus !== '全部') {
      filtered = filtered.filter(customer => customer.status === selectedStatus);
    }
    
    // 应用区域筛选
    if (selectedArea !== '全部') {
      filtered = filtered.filter(customer => customer.location === selectedArea);
    }
    
    // 应用跟进状态筛选
    if (selectedFollowUpStatus !== '全部') {
      filtered = filtered.filter(customer => customer.followUpStatus === selectedFollowUpStatus);
    }
  } else {
    console.log('管理员不应用额外筛选条件，始终显示所有客户');
    // 确保管理员查看所有客户，重置筛选状态
    setSelectedStatus('全部');
    setSelectedArea('全部');
    setSelectedFollowUpStatus('全部');
    // 强制使用完整数据集，忽略之前的任何过滤
    filtered = [...customers];
  }
  
  // 应用排序，但仅对非管理员角色，管理员不需要排序
  if (sortConfig && user?.role !== 'admin') {
    filtered.sort((a, b) => {
      if (a[sortConfig.key as keyof typeof a] < b[sortConfig.key as keyof typeof b]) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (a[sortConfig.key as keyof typeof a] > b[sortConfig.key as keyof typeof b]) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
  }
        
  // 对管理员和非管理员分别处理统计数据
  let statusCounts, customerStatusData, customerAreaData, customerIndustryData;
  
  if (user?.role === 'admin') {
    // 管理员使用完整数据计算统计信息
    statusCounts = {
      '已成交': customers.filter(c => c.status === '已成交').length,
      '跟进中': customers.filter(c => c.status === '跟进中').length,
      '潜在客户': customers.filter(c => c.status === '潜在客户').length,
      '已流失': customers.filter(c => c.status === '已流失').length
    };
    
    // 构建客户状态分布数据
    customerStatusData = [
      { name: '已成交', value: statusCounts['已成交'], color: '#10b981' },
      { name: '跟进中', value: statusCounts['跟进中'], color: '#f59e0b' },
      { name: '潜在客户', value: statusCounts['潜在客户'], color: '#3b82f6' },
      { name: '已流失', value: statusCounts['已流失'], color: '#ef4444' }
    ];
    
    // 构建客户区域分布数据
    customerAreaData = [
      { name: '北京', value: customers.filter(c => c.location === '北京').length },
      { name: '上海', value: customers.filter(c => c.location === '上海').length },
      { name: '广州', value: customers.filter(c => c.location === '广州').length },
      { name: '深圳', value: customers.filter(c => c.location === '深圳').length },
      { name: '其他', value: customers.filter(c => c.location === '其他').length }
    ];
    
    // 构建客户行业分布数据
    customerIndustryData = [
      { name: '科技', value: customers.filter(c => c.company.includes('科技')).length },
      { name: '金融', value: customers.filter(c => c.company.includes('金融')).length },
      { name: '互联网', value: customers.filter(c => c.company.includes('互联网')).length },
      { name: '教育', value: customers.filter(c => c.company.includes('教育')).length },
      { name: '其他', value: customers.filter(c => !['科技', '金融', '互联网', '教育'].some(keyword => c.company.includes(keyword))).length }
    ];
  } else {
    // 非管理员使用筛选后的数据计算统计信息
    statusCounts = {
      '已成交': filtered.filter(c => c.status === '已成交').length,
      '跟进中': filtered.filter(c => c.status === '跟进中').length,
      '潜在客户': filtered.filter(c => c.status === '潜在客户').length,
      '已流失': filtered.filter(c => c.status === '已流失').length
    };
    
    // 构建客户状态分布数据
    customerStatusData = [
      { name: '已成交', value: statusCounts['已成交'], color: '#10b981' },
      { name: '跟进中', value: statusCounts['跟进中'], color: '#f59e0b' },
      { name: '潜在客户', value: statusCounts['潜在客户'], color: '#3b82f6' },
      { name: '已流失', value: statusCounts['已流失'], color: '#ef4444' }
    ];
    
    // 构建客户区域分布数据
    customerAreaData = [
      { name: '北京', value: filtered.filter(c => c.location === '北京').length },
      { name: '上海', value: filtered.filter(c => c.location === '上海').length },
      { name: '广州', value: filtered.filter(c => c.location === '广州').length },
      { name: '深圳', value: filtered.filter(c => c.location === '深圳').length },
      { name: '其他', value: filtered.filter(c => c.location === '其他').length }
    ];
    
    // 构建客户行业分布数据
    customerIndustryData = [
      { name: '科技', value: filtered.filter(c => c.company.includes('科技')).length },
      { name: '金融', value: filtered.filter(c => c.company.includes('金融')).length },
      { name: '互联网', value: filtered.filter(c => c.company.includes('互联网')).length },
      { name: '教育', value: filtered.filter(c => c.company.includes('教育')).length },
      { name: '其他', value: filtered.filter(c => !['科技', '金融', '互联网', '教育'].some(keyword => c.company.includes(keyword))).length }
    ];
  }
  
  // 更新客户列表
  console.log('最终筛选后的客户数量:', filtered.length);
  setFilteredCustomers(filtered);
  setAllCustomers(customers);
      } catch (error) {
        console.error('获取和筛选客户数据失败', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchAndFilterCustomers();
  }, [user, searchTerm, selectedStatus, selectedArea, selectedFollowUpStatus, sortConfig]);

  // 处理排序
  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  // 打开客户详情
  const openCustomerDetail = (customer: Customer) => {
    setSelectedCustomer(customer);
    setIsDetailModalOpen(true);
  };

  // 打开编辑客户模态框
  const openEditModal = (customer: Customer) => {
    setSelectedCustomer(customer);
    setEditCustomerData({...customer});
    setIsEditModalOpen(true);
  };

  // 打开添加客户模态框
  const openAddModal = () => {
    setIsAddModalOpen(true);
  };

  // 处理编辑客户信息
  const handleEditCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer || !selectedCustomer.id) return;
    
    try {
      const updatedCustomer = await dataService.updateCustomer(selectedCustomer.id, editCustomerData);
      if (updatedCustomer) {
        // 更新本地客户列表
        setAllCustomers(prev => prev.map(c => c.id === selectedCustomer.id ? updatedCustomer : c));
        
        // 关闭模态框
        setIsEditModalOpen(false);
        toast.success('客户信息已更新');
      }
    } catch (error) {
      console.error('更新客户信息失败', error);
      toast.error('更新客户信息失败，请重试');
    }
  };

  // 状态列表
  const statuses = ['全部', '已成交', '跟进中', '潜在客户', '已流失'];
  
  // 区域列表
  const areas = ['全部', '北京', '上海', '广州', '深圳', '其他'];
  
  // 跟进状态列表
  const followUpStatuses = ['全部', '已完成', '进行中', '待跟进'];

  // 计算统计数据
  const totalCustomers = filteredCustomers.length;
  const convertedCustomers = filteredCustomers.filter(customer => customer.status === '已成交').length;
  const followUpCustomers = filteredCustomers.filter(customer => customer.followUpStatus === '待跟进' || customer.followUpStatus === '进行中').length;

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900 overflow-hidden">
      {/* 使用统一的Sidebar组件 */}
      <Sidebar 
        sidebarOpen={sidebarOpen} 
        setSidebarOpen={setSidebarOpen} 
        currentPath="/customer-management"
      />

      {/* 主内容区域 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* 顶部导航栏 */}
        <header className="bg-white dark:bg-gray-800 shadow-sm z-20">
          <div className="px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="lg:hidden text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 mr-4"
              >
                <i className="fas fa-bars"></i>
              </button>
              <h1 className="text-xl font-semibold text-gray-800 dark:text-white">客户信息管理</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 rounded-full text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700/50 relative"><i className="fas fa-bell"></i>
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={openAddModal}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center"
              >
                <Plus size={16} className="mr-2" />
                添加客户
              </motion.button>
       </div>
     </div>
     
     {/* 编辑客户模态框 */}
     {isEditModalOpen && selectedCustomer && (
       <motion.div
         initial={{ opacity: 0 }}
         animate={{ opacity: 1 }}
         exit={{ opacity: 0 }}
         className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
         onClick={() => setIsEditModalOpen(false)}
       >
         <motion.div
           initial={{ scale: 0.9, y: 20 }}
           animate={{ scale: 1, y: 0 }}
           exit={{ scale: 0.9, y: 20 }}
           className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
           onClick={(e) => e.stopPropagation()}
         >
           <div className="p-6">
             <div className="flex items-center justify-between mb-6">
               <h2 className="text-2xl font-bold text-gray-800 dark:text-white">编辑客户信息</h2>
               <button
                 onClick={() => setIsEditModalOpen(false)}
                 className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
               >
                 <i className="fas fa-times text-xl"></i>
               </button>
             </div>

             <form className="space-y-4" onSubmit={handleEditCustomer}>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">客户姓名</label>
                   <input
                     type="text"
                     value={editCustomerData.name || ''}
                     onChange={(e) => setEditCustomerData({...editCustomerData, name: e.target.value})}
                     className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                     placeholder="请输入客户姓名"
                     required
                   />
                 </div>
                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">联系电话</label>
                   <input
                     type="tel"
                     value={editCustomerData.phone || ''}
                     onChange={(e) => setEditCustomerData({...editCustomerData, phone: e.target.value})}
                     className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                     placeholder="请输入联系电话"
                     required
                   />
                 </div>
                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">电子邮箱</label>
                   <input
                     type="email"
                     value={editCustomerData.email || ''}
                     onChange={(e) => setEditCustomerData({...editCustomerData, email: e.target.value})}
                     className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                     placeholder="请输入电子邮箱"
                     required
                   />
                 </div>
                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">所在地区</label>
                   <select
                     value={editCustomerData.location || ''}
                     onChange={(e) => setEditCustomerData({...editCustomerData, location: e.target.value})}
                     className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                   >
                     <option value="">请选择地区</option>
                     <option value="北京">北京</option>
                     <option value="上海">上海</option>
                     <option value="广州">广州</option>
                     <option value="深圳">深圳</option>
                     <option value="其他">其他</option>
                   </select>
                 </div>
                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">公司名称</label>
                   <input
                     type="text"
                     value={editCustomerData.company || ''}
                     onChange={(e) => setEditCustomerData({...editCustomerData, company: e.target.value})}
                     className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                     placeholder="请输入公司名称"
                     required
                   />
                 </div>
                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">职位</label>
                   <input
                     type="text"
                     value={editCustomerData.position || ''}
                     onChange={(e) => setEditCustomerData({...editCustomerData, position: e.target.value})}
                     className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                     placeholder="请输入职位"
                   />
                 </div>
                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">客户状态</label>
                   <select
                     value={editCustomerData.status || ''}
                     onChange={(e) => setEditCustomerData({...editCustomerData, status: e.target.value})}
                     className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                   >
                     <option value="潜在客户">潜在客户</option>
                     <option value="跟进中">跟进中</option>
                     <option value="已成交">已成交</option>
                     <option value="已流失">已流失</option>
                   </select>
                 </div>
                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">跟进状态</label>
                   <select
                     value={editCustomerData.followUpStatus || ''}
                     onChange={(e) => setEditCustomerData({...editCustomerData, followUpStatus: e.target.value})}
                     className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                   >
                     <option value="已完成">已完成</option>
                     <option value="进行中">进行中</option>
                     <option value="待跟进">待跟进</option>
                   </select>
                 </div>
                 {user?.role === 'admin' && (
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">负责业务员</label>
                     <select
                       value={editCustomerData.salesperson || ''}
                       onChange={(e) => setEditCustomerData({...editCustomerData, salesperson: e.target.value})}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                     >
                       <option value="张三">张三</option>
                       <option value="李四">李四</option>
                       <option value="王五">王五</option>
                       <option value="赵六">赵六</option>
                       <option value="钱七">钱七</option>
                     </select>
                   </div>
                 )}
               </div>

               <div>
                 <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">客户标签</label>
                 <div className="flex flex-wrap gap-2">
                   {['重要客户', '潜在客户', '高价值客户', '技术类', '管理类', '营销类', '设计类'].map((tag) => (
                     <label key={tag} className="inline-flex items-center cursor-pointer">
                       <input 
                         type="checkbox" 
                         className="sr-only peer" 
                         checked={(editCustomerData.tags as string[] || []).includes(tag)}
                         onChange={(e) => {
                           const currentTags = editCustomerData.tags as string[] || [];
                           if (e.target.checked) {
                             setEditCustomerData({...editCustomerData, tags: [...currentTags, tag]});
                           } else {
                             setEditCustomerData({...editCustomerData, tags: currentTags.filter(t => t !== tag)});
                           }
                         }}
                       />
                       <div className="w-10 h-5 bg-gray-200 dark:bg-gray-700 rounded-full peer peer-checked:bg-blue-600 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"></div>
                       <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">{tag}</span>
                     </label>
                   ))}
                 </div>
               </div>

               <div className="mt-6 flex justify-end">
                 <button
                   type="button"
                   onClick={() => setIsEditModalOpen(false)}
                   className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors mr-2"
                 >
                   取消
                 </button>
                 <button
                   type="submit"
                   className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                 >
                   保存更改
                 </button>
               </div>
             </form>
           </div>
         </motion.div>
       </motion.div>
     )}
        </header>

        {/* 页面内容 */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-gray-50 dark:bg-gray-900">
          {/* 统计卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">客户总数</p>
                  <h3 className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{totalCustomers}</h3>
                </div>
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400">
                  <Users size={24} />
                </div>
              </div>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">已成交客户</p>
                  <h3 className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{convertedCustomers}</h3>
                </div>
                <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center text-green-600 dark:text-green-400">
                  <DollarSign size={24} />
                </div>
              </div>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">待跟进客户</p>
                  <h3 className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{followUpCustomers}</h3>
                </div>
                <div className="w-12 h-12 rounded-full bg-yellow-100 dark:bg-yellow-900/50 flex items-center justify-center text-yellow-600 dark:text-yellow-400">
                  <Clock size={24} />
                </div>
              </div>
            </motion.div>
          </div>

          {/* 图表区域 */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="mb-4">
                <h3 className="font-semibold text-gray-800 dark:text-white">客户状态分布</h3>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={customerStatusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}人`}
                    >
                      {customerStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: theme === 'dark' ? '#1f2937' : '#ffffff',
                        borderColor: theme === 'dark' ? '#374151' : '#e5e7eb',
                        color: theme === 'dark' ? '#f3f4f6' : '#1f2937'
                      }}
                      formatter={(value) => [`${value}人`, '客户数量']}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="mb-4">
                <h3 className="font-semibold text-gray-800 dark:text-white">客户区域分布</h3>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={customerAreaData}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#374151' : '#e5e7eb'} />
                    <XAxis dataKey="name" stroke={theme === 'dark' ? '#9ca3af' : '#6b7280'} />
                    <YAxis stroke={theme === 'dark' ? '#9ca3af' : '#6b7280'} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: theme === 'dark' ? '#1f2937' : '#ffffff',
                        borderColor: theme === 'dark' ? '#374151' : '#e5e7eb',
                        color: theme === 'dark' ? '#f3f4f6' : '#1f2937'
                      }}
                      formatter={(value) => [`${value}人`, '客户数量']}
                    />
                    <Bar dataKey="value" fill="#3b82f6" name="客户数量" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="mb-4">
                <h3 className="font-semibold text-gray-800 dark:text-white">客户行业分布</h3>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart layout="vertical" data={customerIndustryData}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#374151' : '#e5e7eb'} />
                    <XAxis type="number" stroke={theme === 'dark' ? '#9ca3af' : '#6b7280'} />
                    <YAxis dataKey="name" type="category" stroke={theme === 'dark' ? '#9ca3af' : '#6b7280'} width={80} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: theme === 'dark' ? '#1f2937' : '#ffffff',
                        borderColor: theme === 'dark' ? '#374151' : '#e5e7eb',
                        color: theme === 'dark' ? '#f3f4f6' : '#1f2937'
                      }}
                      formatter={(value) => [`${value}人`, '客户数量']}
                    />
                    <Bar dataKey="value" fill="#8b5cf6" name="客户数量" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          </div>

  {/* 筛选和搜索区域 */}
  <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700 mb-6">
    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
      <div className={`flex-1 relative ${user?.role === 'admin' ? 'text-gray-500 dark:text-gray-400' : ''}`}>
        <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        <input
          disabled={user?.role === 'admin'}
          title={user?.role === 'admin' ? '管理员始终查看所有客户，搜索功能已禁用' : '搜索客户姓名、公司或邮箱...'}
                  type="text"
                  placeholder="搜索客户姓名、公司或邮箱..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>
              
  {/* 管理员不显示任何筛选器，始终显示所有客户 */}
  {user?.role !== 'admin' && (
    <div className="flex flex-wrap gap-2">
      {/* 状态筛选 */}
      <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none"
                  >
                    {statuses.map(status => (
                      <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                  
                  {/* 区域筛选 */}
                  <select
                    value={selectedArea}
                    onChange={(e) => setSelectedArea(e.target.value)}
                    className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none"
                  >
                    {areas.map(area => (
                      <option key={area} value={area}>{area}</option>
                    ))}
                  </select>
                  
                  {/* 跟进状态筛选 */}
                  <select
                    value={selectedFollowUpStatus}
                    onChange={(e) => setSelectedFollowUpStatus(e.target.value)}
                    className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none"
                  >
                    {followUpStatuses.map(status => (
                      <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                  
                  {/* 更多筛选按钮 */}
                  <button
                    onClick={() => setIsFilterDropdownOpen(!isFilterDropdownOpen)}
                    className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-all flex items-center"
                  >
                    <Filter size={16} className="mr-2" />
                    筛选
                    <ChevronDown size={16} className="ml-1" />
                  </button>
                </div>
              )}
            </div>
            
            {/* 筛选下拉面板 */}
            {isFilterDropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">负责业务员</label>
                    <select
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    >
                      <option value="">全部</option>
                      <option value="张三">张三</option>
                      <option value="李四">李四</option>
                      <option value="王五">王五</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">标签</label>
                    <select
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    >
                      <option value="">全部</option>
                      <option value="重要客户">重要客户</option>
                      <option value="潜在客户">潜在客户</option>
                      <option value="高价值客户">高价值客户</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">创建时间</label>
                    <input
                      type="date"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    />
                  </div>
                </div>
                <div className="mt-4 flex justify-end gap-2">
                  <button className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-all">
                    重置
                  </button>
                  <button className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-all">
                    应用筛选
                  </button>
                </div>
              </motion.div>
            )}
          </div>

          {/* 客户列表 */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden mb-6">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700/50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:text-blue-600 dark:hover:text-blue-400"
                      onClick={() => handleSort('name')}
                    >
                      <div className="flex items-center">
                        客户信息
                        {sortConfig?.key === 'name' && (
                          <i className={`fas ml-1 ${sortConfig.direction === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                        )}
                      </div>
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"
                    >
                      联系方式
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"
                    >
                      公司信息
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:text-blue-600 dark:hover:text-blue-400"
                      onClick={() => handleSort('status')}
                    >
                      <div className="flex items-center">
                        状态
                        {sortConfig?.key === 'status' && (
                          <i className={`fas ml-1 ${sortConfig.direction === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                        )}
                      </div>
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"
                    >
                      负责业务员
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:text-blue-600 dark:hover:text-blue-400"
                      onClick={() => handleSort('lastContact')}
                    >
                      <div className="flex items-center">
                        最后联系
                        {sortConfig?.key === 'lastContact' && (
                          <i className={`fas ml-1 ${sortConfig.direction === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                        )}
                      </div>
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"
                    >
                      操作
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {filteredCustomers.length > 0 ? (
                    filteredCustomers.map((customer) => (
                      <motion.tr 
                        key={customer.id}
                        whileHover={{ backgroundColor: theme === 'dark' ? 'rgba(55, 65, 81, 0.5)' : 'rgba(249, 250, 251, 1)' }}
                        className="transition-colors"
                      >
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              <img
                                className="h-10 w-10 rounded-full object-cover"
                                src={customer.avatar}
                                alt={customer.name}
                              />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-800 dark:text-white">{customer.name}</div>
                              <div className="text-sm text-gray-500 dark:text-gray-400">
                                {customer.tags.map((tag, index) => (
                                  <span key={index} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300 mr-1">
                                    {tag}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                          <div className="flex items-center mb-1">
                            <Phone size={14} className="mr-2 text-gray-400" />
                            {customer.phone}
                          </div>
                          <div className="flex items-center">
                            <Mail size={14} className="mr-2 text-gray-400" />
                            {customer.email}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                          <div className="flex items-center mb-1">
                            <Briefcase size={14} className="mr-2 text-gray-400" />
                            {customer.company}
                          </div>
                          <div className="flex items-center">
                            <MapPin size={14} className="mr-2 text-gray-400" />
                            {customer.location}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            customer.status === '已成交'
                              ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                              : customer.status === '跟进中'
                              ? 'bg-yellow-100 dark:bg-yellow-900/50 text-yellow-800 dark:text-yellow-300'
                              : 'bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-300'
                          }`}>
                            {customer.status}
                          </span>
                          <div className="mt-1">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              customer.followUpStatus === '已完成'
                                ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                                : customer.followUpStatus === '待跟进'
                                ? 'bg-yellow-100 dark:bg-yellow-900/50 text-yellow-800 dark:text-yellow-300'
                                : 'bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-300'
                            }`}>
                              {customer.followUpStatus}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                          {customer.salesperson}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                          {customer.lastContact}
                        </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                   <button 
                     onClick={() => openCustomerDetail(customer)}
                     className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 mr-3"
                   >
                     详情
                   </button>
                   {user?.role === 'admin' || user?.name === customer.salesperson ? (
                     <>
                       <button 
                         onClick={() => openEditModal(customer)}
                         className="text-green-600 dark:text-green-400 hover:text-green-900 dark:hover:text-green-300 mr-3"
                       >
                         编辑
                       </button>
                       <button 
                         onClick={async () => {
                           if (window.confirm(`确定要删除客户 ${customer.name} 吗？`)) {
                             try {
                               const success = await dataService.deleteCustomer(customer.id);
                               if (success) {
                                 toast.success('客户已成功删除');
                                 // 重新加载客户列表
                                 const updatedCustomers = await dataService.getCustomers();
                                 setAllCustomers(updatedCustomers);
                               } else {
                                 toast.error('删除客户失败');
                               }
                             } catch (error) {
                               console.error('删除客户时出错:', error);
                               toast.error('删除客户失败，请重试');
                             }
                           }
                         }}
                         className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300"
                       >
                         删除
                       </button>
                     </>
                   ) : null}
                 </td>
                      </motion.tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="px-6 py-12 text-center">
                        <Empty />
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            {/* 分页控件 */}
            {filteredCustomers.length > 0 && (
              <div className="px-4 py-3 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 sm:px-6 flex items-center justify-between">
                <div className="hidden sm:block">
                  <p className="text-sm text-gray-700 dark:text-gray-300">
                    显示 <span className="font-medium">1</span> 到 <span className="font-medium">{filteredCustomers.length}</span> 条，共 <span className="font-medium">{filteredCustomers.length}</span> 条结果
                  </p>
                </div>
                <div className="flex-1 flex justify-between sm:justify-end">
                  <button
                    className="relative inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled
                  >
                    上一页
                  </button>
                  <button
                    className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled
                  >
                    下一页
                  </button>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* 客户详情模态框 */}
      {isDetailModalOpen && selectedCustomer && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          onClick={() => setIsDetailModalOpen(false)}
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">客户详情</h2>
                <button
                  onClick={() => setIsDetailModalOpen(false)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>

              <div className="flex flex-col md:flex-row gap-6 mb-6">
                <div className="flex-shrink-0">
                  <img
                    src={selectedCustomer.avatar}
                    alt={selectedCustomer.name}
                    className="w-32 h-32 rounded-full object-cover border-4 border-white dark:border-gray-700 shadow-md"
                  />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">{selectedCustomer.name}</h3>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedCustomer.tags.map((tag, index) => (
                      <span key={index} className="px-3 py-1 bg-blue-50 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 text-sm rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center">
                      <Phone size={16} className="text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-300">{selectedCustomer.phone}</span>
                    </div>
                    <div className="flex items-center">
                      <Mail size={16} className="text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-300">{selectedCustomer.email}</span>
                    </div>
                    <div className="flex items-center">
                      <Briefcase size={16} className="text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-300">{selectedCustomer.company}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin size={16} className="text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-300">{selectedCustomer.location}</span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full mr-2 ${
                        selectedCustomer.status === '已成交'
                          ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                          : selectedCustomer.status === '跟进中'
                          ? 'bg-yellow-100 dark:bg-yellow-900/50 text-yellow-800 dark:text-yellow-300'
                          : 'bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-300'
                      }`}>
                        {selectedCustomer.status}
                      </span>
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        selectedCustomer.followUpStatus === '已完成'
                          ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                          : selectedCustomer.followUpStatus === '待跟进'
                          ? 'bg-yellow-100 dark:bg-yellow-900/50 text-yellow-800 dark:text-yellow-300'
                          : 'bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-300'
                      }`}>
                        {selectedCustomer.followUpStatus}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <UserPlus size={16} className="text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-300">负责业务员: {selectedCustomer.salesperson}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">培训历史</h4>
                {selectedCustomer.trainingHistory.length > 0 ? (
                  <div className="space-y-3">
                    {selectedCustomer.trainingHistory.map((training) => (
                      <div key={training.id} className="flex items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400">
                          <Calendar size={20} />
                        </div>
                        <div className="ml-3 flex-1">
                          <p className="text-sm font-medium text-gray-800 dark:text-white">{training.name}</p>
                          <div className="flex items-center mt-1">
                            <span className="text-xs text-gray-500 dark:text-gray-400 mr-4">
                              {training.date}
                            </span>
                            <span className={`px-2 py-0.5 rounded-full text-xs ${
                              training.status === '已完成'
                                ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                                : 'bg-yellow-100 dark:bg-yellow-900/50 text-yellow-800 dark:text-yellow-300'
                            }`}>
                              {training.status}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400">暂无培训记录</p>
                )}
              </div>

              <div className="mb-6">
                <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">跟进记录</h4>
                <div className="space-y-3">
                  {/* 模拟数据 */}
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center text-purple-600 dark:text-purple-400">
                        <UserCircle size={16} />
                      </div>
                      <div className="ml-3 flex-1">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium text-gray-800 dark:text-white">
                            {selectedCustomer.salesperson}的跟进记录 #{i}
                          </p>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            2025-10-{i + 15}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          与客户沟通了培训需求，客户对{selectedCustomer.trainingHistory.length > 0 ? selectedCustomer.trainingHistory[0].name : '我们的培训课程'}表现出浓厚兴趣，
                          计划在近期安排进一步的详细咨询。
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  onClick={() => setIsDetailModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors mr-2"
                >
                  关闭
                </button>
                {(user?.role === 'admin' || user?.name === selectedCustomer.salesperson) && (
                  <button className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors">
                    安排跟进
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* 添加客户模态框 */}
      {isAddModalOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          onClick={() => setIsAddModalOpen(false)}
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">添加客户</h2>
                <button
                  onClick={() => setIsAddModalOpen(false)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>

              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">客户姓名</label>
                    <input
                      type="text"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="请输入客户姓名"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">联系电话</label>
                    <input
                      type="tel"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="请输入联系电话"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">电子邮箱</label>
                    <input
                      type="email"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="请输入电子邮箱"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">所在地区</label>
                    <select
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    >
                      <option value="">请选择地区</option>
                      <option value="北京">北京</option>
                      <option value="上海">上海</option>
                      <option value="广州">广州</option>
                      <option value="深圳">深圳</option>
                      <option value="其他">其他</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">公司名称</label>
                    <input
                      type="text"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="请输入公司名称"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">职位</label>
                    <input
                      type="text"
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      placeholder="请输入职位"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">客户状态</label>
                    <select
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    >
                      <option value="潜在客户">潜在客户</option>
                      <option value="跟进中">跟进中</option>
                      <option value="已成交">已成交</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">负责业务员</label>
                    <select
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      defaultValue={user?.role === 'salesperson' ? user.name : ''}
                      disabled={user?.role === 'salesperson'}
                    >
                      {user?.role === 'salesperson' ? (
                        <option value={user.name}>{user.name}</option>
                      ) : (
                        <>
                          <option value="">请选择业务员</option>
                          <option value="张三">张三</option>
                          <option value="李四">李四</option>
                          <option value="王五">王五</option>
                          <option value="赵六">赵六</option>
                          <option value="钱七">钱七</option>
                        </>
                      )}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">客户标签</label>
                  <div className="flex flex-wrap gap-2">
                    {['重要客户', '潜在客户', '高价值客户', '技术类', '管理类', '营销类', '设计类'].map((tag) => (
                      <label key={tag} className="inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" />
                        <div className="w-10 h-5 bg-gray-200 dark:bg-gray-700 rounded-full peer peer-checked:bg-blue-600 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"></div>
                        <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">{tag}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">客户需求</label>
                  <textarea
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all min-h-[100px]"
                    placeholder="请输入客户需求描述"
                  ></textarea>
                </div>

                <div className="mt-6 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors mr-2"
                  >
                    取消
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                  >
                    保存客户
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
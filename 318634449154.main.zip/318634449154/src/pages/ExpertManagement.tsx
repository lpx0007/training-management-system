import { useState, useContext, useEffect } from 'react';
import { AuthContext } from '@/contexts/authContext';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useTheme } from '@/hooks/useTheme';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend } from 'recharts';
import { 
  UserCheck, 
  Search, 
  Filter, 
  ChevronDown, 
  Download, 
  Star, 
  Plus, 
  Edit, 
  Trash2, 
  Eye,
  MapPin,
  Calendar,
  Briefcase,
  GraduationCap,
  BarChart2,
  DollarSign,
  Users,
  Check
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Empty } from '@/components/Empty';
import { toast } from 'sonner';
import Sidebar from '@/components/Sidebar';

// Mock数据 - 专家列表
const mockExperts = [
  {
    id: 1,
    name: '张教授',
    avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=middle-aged%20asian%20male%20professor%20glasses%20formal%20wear&sign=4ef5da0fa5c152bcda7af488ff1cb2cd',
    title: '计算机科学教授',
    field: '技术培训',
    experience: '15年',
    rating: 4.8,
    courses: ['前端开发进阶', 'React高级应用', 'TypeScript实战'],
    location: '北京',
    available: true,
    bio: '北京大学计算机科学博士，拥有15年前端开发和教学经验，曾在多家知名科技公司担任技术总监。',
    pastSessions: 45,
    totalParticipants: 1200,
    feedback: [
      { id: 1, content: '讲解清晰，案例丰富，收获很大', rating: 5 },
      { id: 2, content: '实战经验分享很有价值', rating: 4 }
    ]
  },
  {
    id: 2,
    name: '李博士',
    avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=middle-aged%20asian%20male%20business%20suit%20confident&sign=b80675e50e25828ae30d7e62a11634c0',
    title: '项目管理专家',
    field: '管理培训',
    experience: '12年',
    rating: 4.6,
    courses: ['项目管理实战', '敏捷开发方法', '团队协作技巧'],
    location: '上海',
    available: true,
    bio: '上海交通大学管理学博士，PMP认证讲师，拥有丰富的项目管理实战经验。',
    pastSessions: 38,
    totalParticipants: 950,
    feedback: [
      { id: 1, content: '理论与实践结合，实用性强', rating: 5 },
      { id: 2, content: '案例分析很到位', rating: 5 }
    ]
  },
  {
    id: 3,
    name: '王设计师',
    avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=young%20asian%20female%20designer%20creative%20expression&sign=0ce13061b383d7965f2872212558e415',
    title: 'UI/UX设计总监',
    field: '设计培训',
    experience: '8年',
    rating: 4.9,
    courses: ['UI设计原理', '用户体验设计', '设计思维'],
    location: '广州',
    available: false,
    bio: '国际知名设计学院毕业，曾在多家互联网公司担任设计总监，拥有丰富的设计和教学经验。',
    pastSessions: 25,
    totalParticipants: 650,
    feedback: [
      { id: 1, content: '设计理念新颖，教学方式生动', rating: 5 },
      { id: 2, content: '非常有启发性', rating: 5 }
    ]
  },
  {
    id: 4,
    name: '陈数据',
    avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=asian%20male%20data%20scientist%20glasses%20professional&sign=1cc6f634b3329b7afd9ba19aa4303442',
    title: '数据科学家',
    field: '技术培训',
    experience: '10年',
    rating: 4.7,
    courses: ['数据分析与可视化', '机器学习基础', 'Python数据分析'],
    location: '深圳',
    available: true,
    bio: '清华大学数学博士，前谷歌数据科学家，拥有丰富的数据分析和教学经验。',
    pastSessions: 32,
    totalParticipants: 850,
    feedback: [
      { id: 1, content: '内容深入浅出，易于理解', rating: 4 },
      { id: 2, content: '案例实用，讲解清晰', rating: 5 }
    ]
  },
  {
    id: 5,
    name: '赵市场',
    avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=asian%20male%20marketing%20executive%20smiling%20confident&sign=e8dee45842ab7858dcfc95863cb6c024',
    title: '市场营销专家',
    field: '营销培训',
    experience: '14年',
    rating: 4.5,
    courses: ['市场营销策略', '数字营销', '品牌管理'],
    location: '北京',
    available: true,
    bio: '复旦大学MBA，曾在多家世界500强企业担任营销总监，拥有丰富的市场营销实战经验。',
    pastSessions: 42,
    totalParticipants: 1100,
    feedback: [
      { id: 1, content: '实战经验丰富，案例分析透彻', rating: 5 },
      { id: 2, content: '实用性强，收获很大', rating: 4 }
    ]
  }
];

// Mock数据 - 专家领域分布
const expertFieldData = [
  { name: '技术培训', value: 2, color: '#3b82f6' },
  { name: '管理培训', value: 1, color: '#10b981' },
  { name: '设计培训', value: 1, color: '#f59e0b' },
  { name: '营销培训', value: 1, color: '#8b5cf6' }
];

// Mock数据 - 专家评分分布
const expertRatingData = [
  { name: '4.5-5分', value: 4 },
  { name: '4-4.5分', value: 1 },
  { name: '3.5-4分', value: 0 },
  { name: '3分以下', value: 0 }
];

// Mock数据 - 经验分布
const experienceData = [
  { name: '5年以下', value: 1 },
  { name: '5-10年', value: 1 },
  { name: '10-15年', value: 3 },
  { name: '15年以上', value: 0 }
];

export default function ExpertManagement() {
  const { user, logout } = useContext(AuthContext);
  const { theme } = useTheme();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedField, setSelectedField] = useState('全部');
  const [selectedExperience, setSelectedExperience] = useState('全部');
  const [selectedAvailability, setSelectedAvailability] = useState('全部');
  const [filteredExperts, setFilteredExperts] = useState(mockExperts);
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const [selectedExpert, setSelectedExpert] = useState<typeof mockExperts[0] | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  // 筛选专家数据
  useEffect(() => {
    let result = [...mockExperts];
    
    // 搜索筛选
    if (searchTerm) {
      result = result.filter(expert => 
        expert.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        expert.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        expert.bio.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // 领域筛选
    if (selectedField !== '全部') {
      result = result.filter(expert => expert.field === selectedField);
    }
    
    // 经验筛选
    if (selectedExperience !== '全部') {
      result = result.filter(expert => {
        const expYears = parseInt(expert.experience);
        switch(selectedExperience) {
          case '5年以下': return expYears < 5;
          case '5-10年': return expYears >= 5 && expYears <= 10;
          case '10-15年': return expYears > 10 && expYears <= 15;
          case '15年以上': return expYears > 15;
          default: return true;
        }
      });
    }
    
    // 可用性筛选
    if (selectedAvailability !== '全部') {
      result = result.filter(expert => expert.available === (selectedAvailability === '可预约'));
    }
    
    setFilteredExperts(result);
  }, [searchTerm, selectedField, selectedExperience, selectedAvailability]);

  // 打开编辑专家模态框
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editExpert, setEditExpert] = useState<typeof mockExperts[0] | null>(null);
  
  const openEditModal = (expert: typeof mockExperts[0]) => {
    setEditExpert(expert);
    setIsEditModalOpen(true);
  };

  // 保存专家编辑
  const saveExpertEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editExpert) return;
    
    try {
      // 在实际应用中，这里应该调用API保存数据
      // 这里仅做前端模拟
      toast.success('专家信息已更新');
      setIsEditModalOpen(false);
    } catch (error) {
      toast.error('保存失败，请重试');
    }
  };

  // 打开专家详情
  const openExpertDetail = (expert: typeof mockExperts[0]) => {
    setSelectedExpert(expert);
    setIsDetailModalOpen(true);
  };

  // 领域列表
  const fields = ['全部', ...Array.from(new Set(mockExperts.map(expert => expert.field)))];

  // 计算统计数据
  const totalExperts = filteredExperts.length;
  const availableExperts = filteredExperts.filter(expert => expert.available).length;
  const avgRating = filteredExperts.reduce((sum, expert) => sum + expert.rating, 0) / filteredExperts.length;

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900 overflow-hidden">
      {/* 使用统一的Sidebar组件 */}
      <Sidebar 
        sidebarOpen={sidebarOpen} 
        setSidebarOpen={setSidebarOpen} 
        currentPath="/expert-management"
      />

      {/* 主内容区域 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* 顶部导航栏 */}
        <header className="bg-white dark:bg-gray-800 shadow-sm z-20">
          <div className="px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="lg:hidden text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 mr-4"
              >
                <i className="fas fa-bars"></i>
              </button>
              <h1 className="text-xl font-semibold text-gray-800 dark:text-white">专家资源管理</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 rounded-full text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700/50 relative">
                <i className="fas fa-bell"></i>
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              {user?.role === 'admin' && (
                <motion.button 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm flex items-center"
                >
                  <Plus size={16} className="mr-2" />
                  添加专家
                </motion.button>
              )}
            </div>
          </div>
        </header>

        {/* 页面内容 */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-gray-50 dark:bg-gray-900">
          {/* 统计卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">专家总数</p>
                  <h3 className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{totalExperts}</h3>
                </div>
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400">
                  <UserCheck size={24} />
                </div>
              </div>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">可预约专家</p>
                  <h3 className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{availableExperts}</h3>
                </div>
                <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center text-green-600 dark:text-green-400">
                  <Check size={24} />
                </div>
              </div>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">平均评分</p>
                  <h3 className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{avgRating.toFixed(1)}</h3>
                </div>
                <div className="w-12 h-12 rounded-full bg-yellow-100 dark:bg-yellow-900/50 flex items-center justify-center text-yellow-600 dark:text-yellow-400">
                  <Star size={24} />
                </div>
              </div>
            </motion.div>
          </div>

          {/* 图表区域 */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="mb-4">
                <h3 className="font-semibold text-gray-800 dark:text-white">专家领域分布</h3>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={expertFieldData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}人`}
                    >
                      {expertFieldData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: theme === 'dark' ? '#1f2937' : '#ffffff',
                        borderColor: theme === 'dark' ? '#374151' : '#e5e7eb',
                        color: theme === 'dark' ? '#f3f4f6' : '#1f2937'
                      }}
                      formatter={(value) => [`${value}人`, '专家数量']}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="mb-4">
                <h3 className="font-semibold text-gray-800 dark:text-white">专家评分分布</h3>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={expertRatingData}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#374151' : '#e5e7eb'} />
                    <XAxis dataKey="name" stroke={theme === 'dark' ? '#9ca3af' : '#6b7280'} />
                    <YAxis stroke={theme === 'dark' ? '#9ca3af' : '#6b7280'} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: theme === 'dark' ? '#1f2937' : '#ffffff',
                        borderColor: theme === 'dark' ? '#374151' : '#e5e7eb',
                        color: theme === 'dark' ? '#f3f4f6' : '#1f2937'
                      }}
                      formatter={(value) => [`${value}人`, '专家数量']}
                    />
                    <Bar dataKey="value" fill="#f59e0b" name="专家数量" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700"
            >
              <div className="mb-4">
                <h3 className="font-semibold text-gray-800 dark:text-white">专家经验分布</h3>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={experienceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#374151' : '#e5e7eb'} />
                    <XAxis dataKey="name" stroke={theme === 'dark' ? '#9ca3af' : '#6b7280'} />
                    <YAxis stroke={theme === 'dark' ? '#9ca3af' : '#6b7280'} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: theme === 'dark' ? '#1f2937' : '#ffffff',
                        borderColor: theme === 'dark' ? '#374151' : '#e5e7eb',
                        color: theme === 'dark' ? '#f3f4f6' : '#1f2937'
                      }}
                      formatter={(value) => [`${value}人`, '专家数量']}
                    />
                    <Bar dataKey="value" fill="#8b5cf6" name="专家数量" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          </div>

          {/* 筛选和搜索区域 */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 border border-gray-100 dark:border-gray-700 mb-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex-1 relative">
                <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="搜索专家姓名、头衔或简介..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>
              
              <div className="flex flex-wrap gap-2">
                {/* 领域筛选 */}
                <select
                  value={selectedField}
                  onChange={(e) => setSelectedField(e.target.value)}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none"
                >
                  {fields.map(field => (
                    <option key={field} value={field}>{field}</option>
                  ))}
                </select>
                
                {/* 经验筛选 */}
                <select
                  value={selectedExperience}
                  onChange={(e) => setSelectedExperience(e.target.value)}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none"
                >
                  <option value="全部">全部经验</option>
                  <option value="5年以下">5年以下</option>
                  <option value="5-10年">5-10年</option>
                  <option value="10-15年">10-15年</option>
                  <option value="15年以上">15年以上</option>
                </select>
                
                {/* 可用性筛选 */}
                <select
                  value={selectedAvailability}
                  onChange={(e) => setSelectedAvailability(e.target.value)}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none"
                >
                  <option value="全部">全部状态</option>
                  <option value="可预约">可预约</option>
                  <option value="不可预约">不可预约</option>
                </select>
                
                {/* 更多筛选按钮 */}
                <button
                  onClick={() => setIsFilterDropdownOpen(!isFilterDropdownOpen)}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-all flex items-center"
                >
                  <Filter size={16} className="mr-2" />
                  筛选
                  <ChevronDown size={16} className="ml-1" />
                </button>
              </div>
            </div>
            
            {/* 筛选下拉面板 */}
            {isFilterDropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-700"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">最低评分</label>
                    <select
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    >
                      <option value="">全部</option>
                      <option value="4.5">4.5分以上</option>
                      <option value="4">4分以上</option>
                      <option value="3.5">3.5分以上</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">擅长课程数</label>
                    <select
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    >
                      <option value="">全部</option>
                      <option value="3">3门以上</option>
                      <option value="5">5门以上</option>
                      <option value="10">10门以上</option>
                    </select>
                  </div>
                </div>
                <div className="mt-4 flex justify-end gap-2">
                  <button className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-all">
                    重置
                  </button>
                  <button className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-all">
                    应用筛选
                  </button>
                </div>
              </motion.div>
            )}
          </div>

          {/* 专家列表 */}
          {filteredExperts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredExperts.map((expert) => (
                <motion.div
                  key={expert.id}
                  whileHover={{ y: -5 }}
                  className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden border border-gray-100 dark:border-gray-700 transition-all"
                >
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center">
                        <div className="relative">
                          <img
                            src={expert.avatar}
                            alt={expert.name}
                            className="w-16 h-16 rounded-full object-cover border-2 border-white dark:border-gray-700 shadow-sm"
                          />
                          {expert.available ? (
                            <span className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white dark:border-gray-700"></span>
                          ) : (
                            <span className="absolute bottom-0 right-0 w-4 h-4 bg-red-500 rounded-full border-2 border-white dark:border-gray-700"></span>
                          )}
                        </div>
                        <div className="ml-4">
                          <h3 className="text-lg font-semibold text-gray-800 dark:text-white">{expert.name}</h3>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{expert.title}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Star size={16} className="text-yellow-400 mr-1" />
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{expert.rating}</span>
                      </div>
                    </div>

                    <div className="space-y-3 mb-4">
                      <div className="flex items-start">
                        <Briefcase size={16} className="text-gray-400 mt-1 mr-2 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">专业领域</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{expert.field}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <Calendar size={16} className="text-gray-400 mt-1 mr-2 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">授课经验</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{expert.experience}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <MapPin size={16} className="text-gray-400 mt-1 mr-2 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">所在地区</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{expert.location}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <GraduationCap size={16} className="text-gray-400 mt-1 mr-2 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">擅长课程</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {expert.courses.slice(0, 3).map((course, index) => (
                              <span key={index} className="px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-xs rounded-full">
                                {course}
                              </span>
                            ))}
                            {expert.courses.length > 3 && (
                              <span className="px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-xs rounded-full">
                                +{expert.courses.length - 3}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <span className="mr-4">{expert.pastSessions}场培训</span>
                        <span>{expert.totalParticipants}人参训</span>
                      </div>
                      <div className="flex space-x-2">
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => openExpertDetail(expert)}
                          className="p-1.5 rounded-lg text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/50 transition-colors"
                          title="查看详情"
                        >
                          <Eye size={16} />
                        </motion.button>
                        {user?.role === 'admin' && (
                          <>
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => openEditModal(expert)}
                              className="p-1.5 rounded-lg text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/50 transition-colors"
                              title="编辑"
                            >
                              <Edit size={16} />
                            </motion.button>
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              className="p-1.5 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/50 transition-colors"
                              title="删除"
                            >
                              <Trash2 size={16} />
                            </motion.button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-12 text-center border border-gray-100 dark:border-gray-700">
              <Empty />
            </div>
          )}
        </main>
      </div>

       {/* 编辑专家模态框 */}
       {isEditModalOpen && editExpert && (
         <motion.div
           initial={{ opacity: 0 }}
           animate={{ opacity: 1 }}
           exit={{ opacity: 0 }}
           className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
           onClick={() => setIsEditModalOpen(false)}
         >
           <motion.div
             initial={{ scale: 0.9, y: 20 }}
             animate={{ scale: 1, y: 0 }}
             exit={{ scale: 0.9, y: 20 }}
             className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
             onClick={(e) => e.stopPropagation()}
           >
             <div className="p-6">
               <div className="flex items-center justify-between mb-6">
                 <h2 className="text-2xl font-bold text-gray-800 dark:text-white">编辑专家信息</h2>
                 <button
                   onClick={() => setIsEditModalOpen(false)}
                   className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                 >
                   <i className="fas fa-times text-xl"></i>
                 </button>
               </div>

               <form className="space-y-4" onSubmit={saveExpertEdit}>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">专家姓名</label>
                     <input
                       type="text"
                       defaultValue={editExpert.name}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">专家头衔</label>
                     <input
                       type="text"
                       defaultValue={editExpert.title}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">专业领域</label>
                     <input
                       type="text"
                       defaultValue={editExpert.field}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">授课经验</label>
                     <input
                       type="text"
                       defaultValue={editExpert.experience}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">所在地区</label>
                     <input
                       type="text"
                       defaultValue={editExpert.location}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                       required
                     />
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">可用性</label>
                     <select
                       defaultValue={editExpert.available}
                       className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                     >
                       <option value={true}>可预约</option>
                       <option value={false}>不可预约</option>
                     </select>
                   </div>
                 </div>

                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">专家简介</label>
                   <textarea
                     defaultValue={editExpert.bio}
                     className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all min-h-[100px]"
                     required
                   ></textarea>
                 </div>

                 <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">擅长课程</label>
                   <div className="flex flex-wrap gap-2">
                     {['前端开发进阶', 'React高级应用', 'TypeScript实战', '项目管理实战', '敏捷开发方法', '数据分析与可视化', '用户体验设计'].map((course) => (
                       <label key={course} className="inline-flex items-center cursor-pointer">
                         <input 
                           type="checkbox" 
                           className="sr-only peer" 
                           defaultChecked={editExpert.courses.includes(course)}
                         />
                         <div className="w-10 h-5 bg-gray-200 dark:bg-gray-700 rounded-full peer peer-checked:bg-blue-600 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"></div>
                         <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">{course}</span>
                       </label>
                     ))}
                   </div>
                 </div>

                 <div className="mt-6 flex justify-end">
                   <button
                     type="button"
                     onClick={() => setIsEditModalOpen(false)}
                     className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors mr-2"
                   >
                     取消
                   </button>
                   <button
                     type="submit"
                     className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                   >
                     保存修改
                   </button>
                 </div>
               </form>
             </div>
           </motion.div>
         </motion.div>
       )}

       {/* 专家详情模态框 */}
      {isDetailModalOpen && selectedExpert && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          onClick={() => setIsDetailModalOpen(false)}
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">专家详情</h2>
                <button
                  onClick={() => setIsDetailModalOpen(false)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>

              <div className="flex flex-col md:flex-row gap-6 mb-6">
                <div className="flex-shrink-0">
                  <img
                    src={selectedExpert.avatar}
                    alt={selectedExpert.name}
                    className="w-32 h-32 rounded-full object-cover border-4 border-white dark:border-gray-700 shadow-md"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-bold text-gray-800 dark:text-white">{selectedExpert.name}</h3>
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      selectedExpert.available
                        ? 'bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-300'
                        : 'bg-red-100 dark:bg-red-900/50 text-red-800 dark:text-red-300'
                    }`}>
                      {selectedExpert.available ? '可预约' : '不可预约'}
                    </span>
                  </div>
                  <p className="text-lg text-gray-600 dark:text-gray-300 mb-4">{selectedExpert.title}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center">
                      <Briefcase size={16} className="text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">{selectedExpert.field}</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar size={16} className="text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">{selectedExpert.experience}授课经验</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin size={16} className="text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">{selectedExpert.location}</span>
                    </div>
                    <div className="flex items-center">
                      <Star size={16} className="text-yellow-400 mr-2" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">评分: {selectedExpert.rating}</span>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">简介</p><p className="text-sm text-gray-700 dark:text-gray-300">{selectedExpert.bio}</p>
                </div>
              </div>

              <div className="mb-6">
                <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">擅长课程</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedExpert.courses.map((course, index) => (
                    <span key={index} className="px-3 py-1 bg-blue-50 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 text-sm rounded-full">
                      {course}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">历史培训统计</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">总培训场次</p>
                    <p className="text-2xl font-bold text-gray-800 dark:text-white">{selectedExpert.pastSessions}</p>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">总参训人数</p>
                    <p className="text-2xl font-bold text-gray-800 dark:text-white">{selectedExpert.totalParticipants}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">学员评价</h4>
                {selectedExpert.feedback.length > 0 ? (
                  <div className="space-y-4">
                    {selectedExpert.feedback.map((item) => (
                      <div key={item.id} className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                size={16}
                                className={i < item.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300 dark:text-gray-600"}
                              />
                            ))}
                          </div>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300">{item.content}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400">暂无评价</p>
                )}
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  onClick={() => setIsDetailModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors mr-2"
                >
                  关闭
                </button>
                {selectedExpert.available && (
                  <button
                    className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
                  >
                    预约专家
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
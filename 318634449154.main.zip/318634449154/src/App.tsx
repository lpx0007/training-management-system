import { Routes, Route, Navigate } from "react-router-dom";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import TrainingPerformance from "@/pages/TrainingPerformance";
import ExpertManagement from "@/pages/ExpertManagement";
import SalesTracking from "@/pages/SalesTracking";
import CustomerManagement from "@/pages/CustomerManagement";
import DataExport from "@/pages/DataExport";
import SalesPersonManagement from "@/pages/SalesPersonManagement";
import PermissionManagement from "@/pages/PermissionManagement";
import { useState } from "react";
import { AuthContext, User } from '@/contexts/authContext';
import { toast } from 'sonner';
import dataService from '@/lib/dataService';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  const login = (username: string, password: string): boolean => {
    const authenticatedUser = dataService.authenticate(username, password);
    if (authenticatedUser) {
      setIsAuthenticated(true);
      setUser(authenticatedUser);
      toast.success(`欢迎登录，${authenticatedUser.name}！`);
      return true;
    }
    toast.error('用户名或密码错误');
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
    toast.info('已安全退出系统');
  };

  // 受保护的路由组件
  const ProtectedRoute = ({ children, requiredRole }: { children: React.ReactNode, requiredRole?: string[] }) => {
    if (!isAuthenticated) {
      return <Navigate to="/login" replace />;
    }
    
    if (requiredRole && user && !requiredRole.includes(user.role)) {
      toast.error('您没有权限访问此页面');
      return <Navigate to="/dashboard" replace />;
    }
    
    return children;
  };

  return (
    <AuthContext.Provider
      value={{ 
        isAuthenticated, 
        user, 
        setIsAuthenticated, 
        setUser, 
        login, 
        logout,
          hasPermission: (permission: string) => {
            // 管理员拥有所有权限
            if (user?.role === 'admin') return true;
            // 业务员默认有添加培训客户的权限
            if (user?.role === 'salesperson' && permission === 'training_add_customer') return true;
            // 检查用户是否有特定权限
            return user?.permissions?.includes(permission) || false;
          },
    canViewCustomer: (customer: {salesperson: string, name?: string}) => {
  // 管理员可以查看所有客户
  if (user?.role === 'admin') {
    console.log('管理员查看客户权限检查通过');
    return true;
  }
  // 业务员只能查看自己的客户
  const canView = user?.name === customer.salesperson;
  console.log(`业务员${user?.name}查看客户${customer.name}权限检查: ${canView}`);
  return canView;
}
      }}
    >
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        } />
        <Route path="/training-performance" element={
          <ProtectedRoute requiredRole={['admin', 'salesperson']}>
            <TrainingPerformance />
          </ProtectedRoute>
        } />
        <Route path="/expert-management" element={
          <ProtectedRoute requiredRole={['admin']}>
            <ExpertManagement />
          </ProtectedRoute>
        } />
        <Route path="/sales-tracking" element={
          <ProtectedRoute requiredRole={['admin']}>
            <SalesTracking />
          </ProtectedRoute>
        } />
        <Route path="/customer-management" element={
          <ProtectedRoute requiredRole={['admin', 'salesperson']}>
            <CustomerManagement />
          </ProtectedRoute>
        } />
        <Route path="/data-export" element={
          <ProtectedRoute requiredRole={['admin']}>
            <DataExport />
          </ProtectedRoute>
        } />
        <Route path="/salesperson-management" element={
          <ProtectedRoute requiredRole={['admin']}>
            <SalesPersonManagement />
          </ProtectedRoute>
        } />
        <Route path="/permission-management" element={
          <ProtectedRoute requiredRole={['admin']}>
            <PermissionManagement />
          </ProtectedRoute>
        } />
      </Routes>
    </AuthContext.Provider>
  );
}

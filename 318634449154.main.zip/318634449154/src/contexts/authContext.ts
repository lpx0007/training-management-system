import { createContext } from "react";

// 用户角色类型
export type UserRole = 'admin' | 'salesperson' | 'expert';

// 用户信息接口
export interface User {
  id: string;
  username: string;
  role: UserRole;
  name: string;
  department?: string;
  permissions?: string[]; // 用户权限列表
}

// 认证上下文接口
interface AuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  setIsAuthenticated: (value: boolean) => void;
  setUser: (user: User | null) => void;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  // 检查用户是否有特定权限
  hasPermission: (permission: string) => boolean;
  // 检查是否可以查看特定客户
  canViewCustomer: (customer: {salesperson: string}) => boolean;
}

export const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  user: null,
  setIsAuthenticated: () => {},
  setUser: () => {},
  login: () => false,
  logout: () => {},
  hasPermission: (permission: string) => {
    // 默认返回false，实际使用时由Provider提供正确实现
    return false;
  },
   canViewCustomer: (customer: {salesperson: string, name?: string}) => {
    // 默认返回true以确保在Provider未设置时也能正常工作
    console.log('默认canViewCustomer被调用，总是返回true');
    return true;
  },
});